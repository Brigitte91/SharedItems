<?php
/**
* Plugin Name: RiJO Shortcodes
* Plugin URI: https://www.rijologistics.nl/
* Description: De shortcodes gebruikt in de website van RiJO
* Version: 1.0.0
* Author: Logo4Life
* Author URI: http://www.logo4life.nl/
* License: GPL2
*/ 

// 


function tarievenslider_weergeven( $atts ){	

$content = '<div class="center">
    <div></div>
    <div></div>
    <div></div>
	<div></div>
	<div></div>
	<div></div>
	<div></div>
	<div></div>
  </div>';

return $content;
	
}
add_shortcode( 'tarievenslider', 'tarievenslider_weergeven' );



function breadcrumbs_weergeven( $atts ){	

$content = "<div class='broodkruimel'>";
$content .= do_shortcode('[wpseo_breadcrumb]');
$content .= "</div>";

return $content;
	
}
add_shortcode( 'breadcrumbs', 'breadcrumbs_weergeven' );



/*

function landenslider_weergeven( $atts ){	

$args = array(
	'category_name'      => "",
	'posts_per_page' => 1
);
	
// The Query
$the_query = new WP_Query( $args );

if($the_query->have_posts()) : while($the_query->have_posts()) : $the_query->the_post();
	
	$link = get_permalink();
	$title = get_the_title();
	$excerpt = get_the_excerpt();
	
	$content = '<a href="'.$link.'"><div class="footerblogtitle">'.$title.'</div></a>
	<div class="footerblogtext">'.$excerpt.'</div>';	
	return $content;
	
	endwhile; endif;
	
}
add_shortcode( 'landenslider', 'landenslider_weergeven' );





function drierecensies_weergeven( $atts ) {

global $wp_query;

$reviewargs = array(
'post_type' => 'recensies',
'posts_per_page' => 3
);
query_posts($reviewargs);

$number = 0;
$total = $wp_query->found_posts;
$content = "";
                  
if (have_posts()) {                        
while (have_posts()) : the_post();

$number++;
$title = get_the_title();
$tekst = get_the_content();
$image = get_the_post_thumbnail_url();
$functie = get_the_excerpt();

if($number != 1) {  } else { $content .= "<div class='custom_row recensies'>"; }
$content .= "<div class='custom_col-sm-4'><div class='custom_column-inner' style='position:relative'><div class='recensiebox'>
<div class='txtrecensie'>
<div class='titelrecensie'>".$title."</div>
<div class='tekstrecensie'>".$tekst."</div>
</div>
</div>
<div class='auteurrecensie'>".$functie."</div>
</div></div>";
if($number == $total) { $content .= "</div>"; }


endwhile; }

wp_reset_query();

return $content;   
	
}
add_shortcode( 'drierecensies', 'drierecensies_weergeven' );



function recensies_cpt() {

register_post_type( 'recensies', array(
  'labels' => array(
    'name' => 'Recensies',
    'singular_name' => 'Recensie',
   ),
  'description' => 'Recensies van Natuurlijke Aandacht',
  'public' => true,
  'menu_position' => 20,
  'menu_icon' => 'dashicons-format-aside',
  'supports' => array( 'title', 'editor', 'thumbnail', 'excerpt' )
));
}
add_action( 'init', 'recensies_cpt' );

*/


function rijo_query_vars( $qvars ) {
    $qvars[] = 'foutmelding';
	$qvars[] = 'send';
    return $qvars;
}
add_filter( 'query_vars', 'rijo_query_vars' );


function loginformulier_weergeven( $atts ) {

$foutmelding = (get_query_var('foutmelding')) ? get_query_var('foutmelding') : false;
if($foutmelding == 'ok') {
$content = '<div class="loginform">
<div class="foutmelding">Gegegevens onjuist, probeer het opnieuw.</div>
<div class="foutmelding voorwaarden">Vergeet niet akkoord te gaan met de voorwaarden.</div>
<form id="loginformulier" method="post" action ="https://webservices.tms-foryou.nl/webservices/loginkey?dashboard=rijo">
<input type="text" placeholder="Gebruikersnaam" name="gebruikersnaam">
<input type="password" placeholder="Wachtwoord" name="wachtwoord">
<input type="checkbox" id="voorwaarden"> <label for="voorwaarden">Ik ga akkoord met de <a target="_blank" href="https://www.rijologistics.nl/wp-content/uploads/2019/10/Expeditievoorwaarden_NL.pdf">voorwaarden</a> en <a target="_blank" href="https://www.rijologistics.nl/privacyverklaring/">privacyverklaring</a></label>
<input onclick="inloggenStart(event)" type="submit" value="Inloggen">
<a href="https://www.rijologistics.nl/wachtwoord-vergeten/" class="wwlinkje">Wachtwoord vergeten? Klik hier</a>
</form>
</div>';
} elseif($foutmelding == 'gebruikersnaam') {
$content = '<div class="loginform">
<div class="foutmelding">Gebruikersnaam niet volledig of incorrect.</div>
<div class="foutmelding voorwaarden">Vergeet niet akkoord te gaan met de voorwaarden.</div>
<form id="loginformulier" method="post" action ="https://webservices.tms-foryou.nl/webservices/loginkey?dashboard=rijo">
<input type="text" placeholder="Gebruikersnaam" name="gebruikersnaam">
<input type="password" placeholder="Wachtwoord" name="wachtwoord">
<input type="checkbox" id="voorwaarden"> <label for="voorwaarden">Ik ga akkoord met de <a target="_blank" href="https://www.rijologistics.nl/wp-content/uploads/2019/10/Expeditievoorwaarden_NL.pdf">voorwaarden</a> en <a target="_blank" href="https://www.rijologistics.nl/privacyverklaring/">privacyverklaring</a></label>
<input onclick="inloggenStart(event)" type="submit" value="Inloggen">
<a href="https://www.rijologistics.nl/wachtwoord-vergeten/" class="wwlinkje">Wachtwoord vergeten? Klik hier</a>
</form>
</div>';	
} elseif($foutmelding == 'incorrect') {
$content = '<div class="loginform">
<div class="foutmelding">Wachtwoord en/of gebruikersnaam incorrect.</div>
<div class="foutmelding voorwaarden">Vergeet niet akkoord te gaan met de voorwaarden.</div>
<form id="loginformulier" method="post" action ="https://webservices.tms-foryou.nl/webservices/loginkey?dashboard=rijo">
<input type="text" placeholder="Gebruikersnaam" name="gebruikersnaam">
<input type="password" placeholder="Wachtwoord" name="wachtwoord">
<input type="checkbox" id="voorwaarden"> <label for="voorwaarden">Ik ga akkoord met de <a target="_blank" href="https://www.rijologistics.nl/wp-content/uploads/2019/10/Expeditievoorwaarden_NL.pdf">voorwaarden</a> en <a target="_blank" href="https://www.rijologistics.nl/privacyverklaring/">privacyverklaring</a></label>
<input onclick="inloggenStart(event)" type="submit" value="Inloggen">
<a href="https://www.rijologistics.nl/wachtwoord-vergeten/" class="wwlinkje">Wachtwoord vergeten? Klik hier</a>
</form>
</div>';	
} else {
$content = '<div class="loginform">
<div class="foutmelding voorwaarden">Vergeet niet akkoord te gaan met de voorwaarden.</div>
<form id="loginformulier" method="post" action ="https://webservices.tms-foryou.nl/webservices/loginkey?dashboard=rijo">
<input type="text" placeholder="Gebruikersnaam" name="gebruikersnaam">
<input type="password" placeholder="Wachtwoord" name="wachtwoord">
<input type="checkbox" id="voorwaarden"> <label for="voorwaarden">Ik ga akkoord met de <a target="_blank" href="https://www.rijologistics.nl/wp-content/uploads/2019/10/Expeditievoorwaarden_NL.pdf">voorwaarden</a> en <a target="_blank" href="https://www.rijologistics.nl/privacyverklaring/">privacyverklaring</a></label>
<input onclick="inloggenStart(event)" type="submit" value="Inloggen">
<a href="https://www.rijologistics.nl/wachtwoord-vergeten/" class="wwlinkje">Wachtwoord vergeten? Klik hier</a>
</form>
</div>';	
}

return $content;   
	
}
add_shortcode( 'loginformulier', 'loginformulier_weergeven' );



function wachtwoordformulier_weergeven( $atts ) {

$foutmelding = (get_query_var('foutmelding')) ? get_query_var('foutmelding') : false;
if($foutmelding == 'ok') {
$content = '<div class="loginform">
<div class="foutmelding groen">We hebben een e-mail verstuurd met uw gebruikersnaam en wachtwoord.</div>

<span>Vul hieronder je e-mailadres in. Je ontvangt een e-mail met een link om een nieuw wachtwoord in te stellen.</span>

<form method="post" action ="https://webservices.tms-foryou.nl/webservices/loginkey?dashboard=rijo&password=mail">
<input type="text" placeholder="E-mailadres" name="emailadres">
<input type="submit" value="Wachtwoord opvragen">
</form>
</div>';
} else if($foutmelding == 'fout') {
$content = '<div class="loginform">
<div class="foutmelding">We konden dit e-mailadres niet terugvinden in onze gegevens.</div>

<span>Vul hieronder je e-mailadres in. Je ontvangt een e-mail met een link om een nieuw wachtwoord in te stellen.</span>

<form method="post" action ="https://webservices.tms-foryou.nl/webservices/loginkey?dashboard=rijo&password=mail">
<input type="text" placeholder="E-mailadres" name="emailadres">
<input type="submit" value="Wachtwoord opvragen">
</form>
</div>';
} else {
$content = '<div class="loginform">

<span>Vul hieronder je e-mailadres in. Je ontvangt een e-mail met een link om een nieuw wachtwoord in te stellen.</span>

<form method="post" action ="https://webservices.tms-foryou.nl/webservices/loginkey?dashboard=rijo&password=mail">
<input type="text" placeholder="E-mailadres" name="emailadres">
<input type="submit" value="Wachtwoord opvragen">
</form>
</div>';
}

return $content;   
	
}
add_shortcode( 'wachtwoordformulier', 'wachtwoordformulier_weergeven' );



function aanmeldformulier_weergeven( $atts ) {

$foutmelding = (get_query_var('send')) ? get_query_var('send') : false;
$content = '<div class="aanmeldform">
<div style="margin-bottom:15px" class="foutmelding allevelden">Vul alle verplichte velden in.</div>
<div style="margin-bottom:15px" class="foutmelding nietgelukt">Helaas is de aanmelding niet gelukt. Neem a.u.b. contact op.</div>
<div style="margin-bottom:15px" class="foutmelding voorwaarden">Vergeet niet akkoord te gaan met de voorwaarden.</div>
<div style="margin-bottom:15px" class="foutmelding groen">Uw aanmelding is geslaagd en u ontvangt over enkele minuten een e-mail ter bevestiging.</div>

<form id="aanmeldformulier" method="post" action="https://webservices.tms-foryou.nl/webservices/send?dashboard=RiJo">
<span class="allevelden">
<span>
<label>Bedrijfsnaam*</label>
<input id="bedrijfsnaam" type="text" placeholder="" name="bedrijfsnaam">
</span>
<span>
<label>Postcode*</label>
<input id="postcode" type="text" placeholder="" name="postcode">
</span>

<span class="helft1">
<label>Straat*</label>
<input id="straat" type="text" placeholder="" name="straat">
</span>
<span class="helft1">
<label>Huisnummer*</label>
<input id="huisnummer" type="text" placeholder="" name="huisnummer">
</span>
<div style="clear:both"></div>

<span>
<label>Toevoeging</label>
<input type="text" placeholder="Optioneel veld" name="toevoeging">
</span>
<span>
<label>Plaats*</label>
<input id="plaats" type="text" placeholder="" name="plaats">
</span>
<span>
<label>Land*</label>
<select name="land">
<option value="Netherlands">Netherlands</option>
<option value="Belgium">Belgium</option>
<option value="Germany">Germany</option>
</select>
</span>

<br /><br />

<span>
<label>Contactpersoon*</label>
<input type="text" id="contactpersoon" placeholder="Voor- en achternaam" name="contactpersoon">
</span>

<span class="helft1">
<label>Telefoon*</label>
<input id="telefoon" type="text" placeholder="" name="telefoon">
</span>
<span class="helft1">
<label>Mobiel*</label>
<input id="mobiel" type="text" placeholder="" name="mobiel">
</span>
<div style="clear:both"></div>

<span class="helft1">
<label>E-mailadres*</label>
<input id="email" type="text" placeholder="" name="email">
</span>
<span class="helft1">
<label>Factuuradres (e-mail)*</label>
<input id="factuuradres" type="text" placeholder="" name="factuuradres">
</span>
<div style="clear:both"></div>

<span>
<label>KvK nummer*</label>
<input id="kvk" type="text" placeholder="" name="kvk">
</span>

<span>
<label>BTW nummer*</label>
<input id="btw" type="text" placeholder="" name="btw">
</span>

<span>
<label>Vul het huidige jaartal in*</label>
<input id="jaartal" type="text" placeholder="Om spam tegen te gaan" name="jaartal">
</span>

</span>

<div style="width:100%;font-size:14px" class="voorwaardenaanmeld"><input type="checkbox" id="voorwaarden"> <label for="voorwaarden">Ik ga akkoord met de <a target="_blank" href="https://www.rijologistics.nl/wp-content/uploads/2019/10/Expeditievoorwaarden_NL.pdf">voorwaarden</a> en <a target="_blank" href="https://www.rijologistics.nl/privacyverklaring/">privacyverklaring</a></label></div>
<input onclick="registrerenStart(event)" type="submit" class="aanmeldbutton" value="Aanmelden">
</form>

</div>';	

if($foutmelding == 'false') {

$content .= '<script>
jQuery(".foutmelding").fadeOut();		
jQuery(".foutmelding.nietgelukt").fadeIn();

jQuery("html, body").animate({
        scrollTop: jQuery("#aanmeldformulier").offset().top - 300
}, 500);
</script>';	
	
} elseif($foutmelding == 'true') {

$content .= '<script>
jQuery(".foutmelding").fadeOut();		
jQuery(".foutmelding.groen").fadeIn();

jQuery("html, body").animate({
        scrollTop: jQuery("#aanmeldformulier").offset().top - 300
}, 500);
</script>';	
	
}

return $content;   
	
}
add_shortcode( 'aanmeldformulier', 'aanmeldformulier_weergeven' );









?>